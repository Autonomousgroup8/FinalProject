
genome="AAAACCCCGGGGTTTTAAAAAAAACCCCGGGGTTTTAAAAAAAACCCCGGGGTTTTAAAAAAAACCCCGGGGTTTTAAAAAAAACCCCGGGGTTTTAAAA"
print(genome)
genome = genome.replace("A" ,"T")
genome = genome.replace("C" ,"G")
genome = genome.replace("G" ,"C")
genome = genome.replace("T" ,"A")

print(genome)
